import { M as MediaProviderLoader, A as AudioProvider, a as MediaSrc, b as MediaType, V as VideoProvider, c as MediaContext, Y as YouTubeProvider, H as HLSProvider, d as VimeoProvider, T as Thumbnail, S as SliderOrientation, e as TextRenderer, f as TextTrack, g as TextTrackList, h as MediaKeyShortcuts } from './dist/types/vidstack-rg4gqF4B.js';
export { ce as AnyMediaProvider, f4 as AudioRadioGroup, f8 as AudioRadioGroupChangeEvent, f6 as AudioRadioGroupEvents, f5 as AudioRadioGroupProps, f7 as AudioRadioOption, bU as AudioTrack, bX as AudioTrackAddEvent, bZ as AudioTrackChangeEvent, bT as AudioTrackList, bW as AudioTrackListEvent, bV as AudioTrackListEvents, bY as AudioTrackRemoveEvent, dQ as CaptionButton, dP as CaptionButtonProps, fw as Captions, fv as CaptionsProps, f9 as CaptionsRadioGroup, fd as CaptionsRadioGroupChangeEvent, fb as CaptionsRadioGroupEvents, fa as CaptionsRadioGroupProps, fc as CaptionsRadioOption, b_ as ChangeAudioTrackEventDetail, f0 as ChapterRadioGroupProps, e$ as ChaptersRadioGroup, f2 as ChaptersRadioGroupChangeEvent, f1 as ChaptersRadioGroupEvents, f3 as ChaptersRadioOption, dy as Controls, dB as ControlsChangeEvent, dA as ControlsEvents, dC as ControlsGroup, dz as ControlsProps, dl as DefaultAudioLayout, dk as DefaultLayout, dq as DefaultLayoutContext, dn as DefaultLayoutProps, dp as DefaultLayoutTranslations, dm as DefaultVideoLayout, bv as FindMediaPlayerEvent, bu as FindMediaPlayerEventDetail, p as FullscreenAdapter, dS as FullscreenButton, dR as FullscreenButtonProps, r as FullscreenChangeEvent, F as FullscreenController, s as FullscreenErrorEvent, q as FullscreenEvents, fn as Gesture, fq as GestureAction, fs as GestureEvent, fp as GestureEventType, fr as GestureEvents, fo as GestureProps, fu as GestureTriggerEvent, ft as GestureWillTriggerEvent, cR as HLSAudioTrackLoadedEvent, cQ as HLSAudioTrackLoadingEvent, cP as HLSAudioTrackSwitchedEvent, cO as HLSAudioTrackSwitchingEvent, cN as HLSAudioTracksUpdatedEvent, df as HLSBackBufferReachedEvent, cz as HLSBufferAppendedEvent, cy as HLSBufferAppendingEvent, cw as HLSBufferCodecsEvent, cx as HLSBufferCreatedEvent, cA as HLSBufferEosEvent, cC as HLSBufferFlushedEvent, cB as HLSBufferFlushingEvent, cv as HLSBufferResetEvent, dg as HLSConstructor, dh as HLSConstructorLoader, cY as HLSCuesParsedEvent, dc as HLSDestroyingEvent, db as HLSErrorEvent, d9 as HLSFpsDropEvent, da as HLSFpsDropLevelCappingEvent, d7 as HLSFragBufferedDataEvent, d8 as HLSFragChangedEvent, d2 as HLSFragDecryptedEvent, d0 as HLSFragLoadEmergencyAbortedEvent, d1 as HLSFragLoadedEvent, c$ as HLSFragLoadingEvent, d6 as HLSFragParsedEvent, d3 as HLSFragParsingInitSegmentEvent, d5 as HLSFragParsingMetadataEvent, d4 as HLSFragParsingUserdataEvent, c_ as HLSInitPtsFoundEvent, dj as HLSInstanceCallback, cp as HLSInstanceEvent, de as HLSKeyLoadedEvent, dd as HLSKeyLoadingEvent, cJ as HLSLevelLoadedEvent, cI as HLSLevelLoadingEvent, cL as HLSLevelPtsUpdatedEvent, cH as HLSLevelSwitchedEvent, cG as HLSLevelSwitchingEvent, cK as HLSLevelUpdatedEvent, cM as HLSLevelsUpdatedEvent, co as HLSLibLoadErrorEvent, cm as HLSLibLoadStartEvent, cn as HLSLibLoadedEvent, di as HLSLibrary, cE as HLSManifestLoadedEvent, cD as HLSManifestLoadingEvent, cF as HLSManifestParsedEvent, cs as HLSMediaAttachedEvent, cr as HLSMediaAttachingEvent, cu as HLSMediaDetachedEvent, ct as HLSMediaDetachingEvent, cl as HLSMediaEvent, cZ as HLSNonNativeTextTracksFoundEvent, ck as HLSProviderEvents, cX as HLSSubtitleFragProcessedEvent, cW as HLSSubtitleTrackLoadedEvent, cV as HLSSubtitleTrackLoadingEvent, cU as HLSSubtitleTrackSwitchEvent, cT as HLSSubtitleTracksClearedEvent, cS as HLSSubtitleTracksUpdatedEvent, cq as HLSUnsupportedEvent, j as List, l as ListAddEvent, k as ListEvents, i as ListItem, n as ListReadonlyChangeEvent, m as ListRemoveEvent, d_ as LiveButton, dZ as LiveButtonProps, v as LogEvent, u as LogEventDetail, L as Logger, t as LoggerEvents, Q as MediaAbortEvent, U as MediaAudioTrackChangeEvent, aZ as MediaAudioTrackChangeRequestEvent, R as MediaAudioTracksChangeEvent, W as MediaAutoplayChangeEvent, $ as MediaAutoplayEvent, _ as MediaAutoplayEventDetail, Z as MediaAutoplayFailEvent, X as MediaAutoplayFailEventDetail, a0 as MediaCanLoadEvent, a2 as MediaCanPlayDetail, a1 as MediaCanPlayEvent, a3 as MediaCanPlayThroughEvent, K as MediaControls, a4 as MediaControlsChangeEvent, a7 as MediaDestroyEvent, a8 as MediaDurationChangeEvent, a9 as MediaEmptiedEvent, aa as MediaEndEvent, ab as MediaEndedEvent, a_ as MediaEnterFullscreenRequestEvent, b0 as MediaEnterPIPRequestEvent, bk as MediaErrorCode, bl as MediaErrorDetail, ac as MediaErrorEvent, O as MediaEvent, N as MediaEvents, a$ as MediaExitFullscreenRequestEvent, b1 as MediaExitPIPRequestEvent, ch as MediaFullscreenAdapter, ad as MediaFullscreenChangeEvent, ae as MediaFullscreenErrorEvent, aY as MediaFullscreenRequestTarget, bd as MediaHidePosterRequestEvent, cc as MediaKeyShortcut, cb as MediaKeyTarget, cd as MediaKeysCallback, ai as MediaLiveChangeEvent, aj as MediaLiveEdgeChangeEvent, b2 as MediaLiveEdgeRequestEvent, ak as MediaLoadStartEvent, af as MediaLoadedDataEvent, ag as MediaLoadedMetadataEvent, bj as MediaLoadingStrategy, ah as MediaLoopChangeEvent, be as MediaLoopRequestEvent, aW as MediaMuteRequestEvent, aH as MediaOrientationChangeEvent, bf as MediaOrientationLockRequestEvent, bg as MediaOrientationUnlockRequestEvent, ax as MediaPIPChangeEvent, ay as MediaPIPErrorEvent, bb as MediaPauseControlsRequestEvent, am as MediaPauseEvent, b6 as MediaPauseRequestEvent, an as MediaPlayEvent, ao as MediaPlayFailEvent, b3 as MediaPlayRequestEvent, du as MediaPlayer, bt as MediaPlayerConnectEvent, I as MediaPlayerEvents, E as MediaPlayerProps, bn as MediaPlayerState, ap as MediaPlayingEvent, aq as MediaPlaysinlineChangeEvent, ar as MediaPosterChangeEvent, at as MediaProgressEvent, as as MediaProgressEventDetail, dx as MediaProvider, cf as MediaProviderAdapter, av as MediaProviderChangeEvent, au as MediaProviderLoaderChangeEvent, dv as MediaProviderProps, aw as MediaProviderSetupEvent, dw as MediaProviderState, az as MediaQualitiesChangeEvent, aA as MediaQualityChangeEvent, b4 as MediaQualityChangeRequestEvent, a5 as MediaRateChangeEvent, b5 as MediaRateChangeRequestEvent, J as MediaRemoteControl, aI as MediaReplayEvent, aT as MediaRequestEvents, bm as MediaResource, ba as MediaResumeControlsRequestEvent, b7 as MediaSeekRequestEvent, aB as MediaSeekedEvent, aC as MediaSeekingEvent, b8 as MediaSeekingRequestEvent, cg as MediaSetupContext, bc as MediaShowPosterRequestEvent, a6 as MediaSourceChangeEvent, aD as MediaSourcesChangeEvent, aE as MediaStalledEvent, aU as MediaStartLoadingRequestEvent, aF as MediaStartedEvent, bs as MediaState, G as MediaStateAccessors, bq as MediaStore, bh as MediaStreamType, aM as MediaStreamTypeChangeEvent, aG as MediaSuspendEvent, aO as MediaTextTrackChangeEvent, aV as MediaTextTrackChangeRequestEvent, aN as MediaTextTracksChangeEvent, aK as MediaTimeUpdateEvent, aJ as MediaTimeUpdateEventDetail, aL as MediaTitleChangeEvent, al as MediaTypeChangeEvent, aX as MediaUnmuteRequestEvent, bw as MediaUserEvents, bi as MediaViewType, aP as MediaViewTypeChangeEvent, aQ as MediaVolumeChange, aR as MediaVolumeChangeEvent, b9 as MediaVolumeChangeRequestEvent, aS as MediaWaitingEvent, ey as Menu, eD as MenuButton, eF as MenuButtonEvents, eE as MenuButtonProps, eG as MenuButtonSelectEvent, eC as MenuCloseEvent, eA as MenuEvents, eH as MenuItem, eM as MenuItems, eQ as MenuItemsProps, eB as MenuOpenEvent, eN as MenuPlacement, eP as MenuPlacementAlign, eO as MenuPlacementSide, eI as MenuPortal, eK as MenuPortalContext, eJ as MenuPortalProps, ez as MenuProps, dU as MuteButton, dT as MuteButtonProps, dW as PIPButton, dV as PIPButtonProps, dO as PlayButton, dN as PlayButtonProps, b$ as PlayerQueryList, c1 as PlayerQueryListChangeEvent, c0 as PlayerQueryListEvents, P as PlayerSrc, br as PlayerStore, fz as Poster, fx as PosterProps, fy as PosterState, fi as QualityRadioGroup, fm as QualityRadioGroupChangeEvent, fl as QualityRadioGroupEvents, fj as QualityRadioGroupProps, fk as QualityRadioOption, eV as Radio, eY as RadioChangeEvent, eX as RadioEvents, eR as RadioGroup, eU as RadioGroupChangeEvent, eT as RadioGroupEvents, eS as RadioGroupProps, e_ as RadioOption, eW as RadioProps, eZ as RadioSelectEvent, z as ScreenOrientationChangeEvent, y as ScreenOrientationChangeEventDetail, w as ScreenOrientationController, x as ScreenOrientationEvents, C as ScreenOrientationLockType, B as ScreenOrientationType, dY as SeekButton, dX as SeekButtonProps, ea as Slider, e6 as SliderCSSVars, ev as SliderChapters, ex as SliderChaptersCSSVars, ew as SliderChaptersProps, ed as SliderController, ee as SliderControllerProps, ec as SliderDelegate, e2 as SliderDragEndEvent, e1 as SliderDragStartEvent, e4 as SliderDragValueChangeEvent, e0 as SliderEvent, d$ as SliderEvents, e5 as SliderPointerValueChangeEvent, en as SliderPreview, ep as SliderPreviewProps, eb as SliderProps, e9 as SliderState, e8 as SliderStore, el as SliderValue, e3 as SliderValueChangeEvent, em as SliderValueProps, ef as SliderVideo, ej as SliderVideoCanPlayEvent, ek as SliderVideoErrorEvent, ei as SliderVideoEvents, eg as SliderVideoProps, eh as SliderVideoState, fe as SpeedRadioGroup, fh as SpeedRadioGroupChangeEvent, fg as SpeedRadioGroupEvents, ff as SpeedRadioGroupProps, bA as TextRenderers, bI as TextTrackAddCueEvent, bQ as TextTrackAddEvent, bK as TextTrackCueChangeEvent, bH as TextTrackErrorEvent, bE as TextTrackEvent, bD as TextTrackEvents, bC as TextTrackInit, bP as TextTrackListEvent, bO as TextTrackListEvents, bS as TextTrackListModeChangeEvent, bG as TextTrackLoadEvent, bF as TextTrackLoadStartEvent, bL as TextTrackModeChangeEvent, bB as TextTrackReadyState, bJ as TextTrackRemoveCueEvent, bR as TextTrackRemoveEvent, fF as ThumbnailCoords, fE as ThumbnailProps, fD as ThumbnailState, fG as ThumbnailsLoader, fA as Time, fB as TimeProps, bx as TimeRange, es as TimeSlider, et as TimeSliderCSSVars, eu as TimeSliderProps, fC as TimeState, dM as ToggleButton, dL as ToggleButtonProps, dD as Tooltip, dG as TooltipContent, dK as TooltipContentProps, dH as TooltipPlacement, dJ as TooltipPlacementAlign, dI as TooltipPlacementSide, dE as TooltipProps, dF as TooltipTrigger, cj as VideoPresentationChangeEvent, ci as VideoPresentationEvents, c3 as VideoQuality, c6 as VideoQualityAddEvent, ca as VideoQualityAutoChangeEvent, c8 as VideoQualityChangeEvent, c9 as VideoQualityChangeEventDetail, c2 as VideoQualityList, c5 as VideoQualityListEvent, c4 as VideoQualityListEvents, c7 as VideoQualityRemoveEvent, er as VolumeSlider, eq as VolumeSliderProps, o as canFullscreen, dr as defaultLayoutContext, ds as getDefaultLayoutLang, bz as getTimeRangesEnd, by as getTimeRangesStart, bM as isTrackCaptionKind, D as mediaContext, bo as mediaState, eL as menuPortalContext, bN as parseJSONCaptionsFile, e7 as sliderState, bp as softResetMediaState, eo as updateSliderPreviewPlacement, dt as useDefaultLayoutContext } from './dist/types/vidstack-rg4gqF4B.js';
import { R as ReadSignal, W as WriteSignal, C as Context, E as EventsTarget, D as Dispose, V as ViewController } from './dist/types/vidstack-YccYOULG.js';
export { a as appendTriggerEvent, f as findTriggerEvent, h as hasTriggerEvent, b as isKeyboardClick, c as isKeyboardEvent, i as isPointerEvent, w as walkTriggerEventChain } from './dist/types/vidstack-YccYOULG.js';
import { VTTCue } from 'media-captions';
export { IconProps } from './icons.js';
import 'hls.js';
import 'media-icons';

declare class AudioProviderLoader implements MediaProviderLoader<AudioProvider> {
    target: HTMLAudioElement;
    canPlay({ src, type }: MediaSrc): boolean;
    mediaType(): MediaType;
    load(): Promise<AudioProvider>;
}

declare class VideoProviderLoader implements MediaProviderLoader<VideoProvider> {
    target: HTMLVideoElement;
    canPlay(src: MediaSrc): boolean;
    mediaType(): MediaType;
    load(ctx: MediaContext): Promise<VideoProvider>;
}

declare class YouTubeProviderLoader implements MediaProviderLoader<YouTubeProvider> {
    target: HTMLIFrameElement;
    canPlay(src: MediaSrc): boolean;
    mediaType(): MediaType;
    load(ctx: MediaContext): Promise<YouTubeProvider>;
}

declare class HLSProviderLoader extends VideoProviderLoader implements MediaProviderLoader<HLSProvider> {
    static supported: boolean;
    canPlay(src: MediaSrc): boolean;
    load(context: any): Promise<HLSProvider>;
}

declare class VimeoProviderLoader implements MediaProviderLoader<VimeoProvider> {
    target: HTMLIFrameElement;
    canPlay(src: MediaSrc): boolean;
    mediaType(): MediaType;
    load(ctx: MediaContext): Promise<VimeoProvider>;
}

/** @see {@link https://www.vidstack.io/docs/player/providers/audio} */
declare function isAudioProvider(provider: any): provider is AudioProvider;
/** @see {@link https://www.vidstack.io/docs/player/providers/video} */
declare function isVideoProvider(provider: any): provider is VideoProvider;
/** @see {@link https://www.vidstack.io/docs/player/providers/hls} */
declare function isHLSProvider(provider: any): provider is HLSProvider;
/** @see {@link https://www.vidstack.io/docs/player/providers/youtube} */
declare function isYouTubeProvider(provider: any): provider is YouTubeProvider;
/** @see {@link https://www.vidstack.io/docs/player/providers/vimeo} */
declare function isVimeoProvider(provider: any): provider is VimeoProvider;
/** @see {@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLAudioElement} */
declare function isHTMLAudioElement(element: unknown): element is HTMLAudioElement;
/** @see {@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLVideoElement} */
declare function isHTMLVideoElement(element: unknown): element is HTMLVideoElement;
/** @see {@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLMediaElement} */
declare function isHTMLMediaElement(element: unknown): element is HTMLMediaElement;
/** @see {@link https://developer.mozilla.org/en-US/docs/Web/API/HTMLIFrameElement} */
declare function isHTMLIFrameElement(element: unknown): element is HTMLIFrameElement;

/**
 * Used to display preview thumbnails when the user is hovering or dragging the time slider.
 * The time ranges in the WebVTT file will automatically be matched based on the current slider
 * pointer position.
 *
 * @attr data-loading - Whether thumbnail image is loading.
 * @attr data-error - Whether an error occurred loading thumbnail.
 * @attr data-hidden - Whether thumbnail is not available or failed to load.
 * @docs {@link https://www.vidstack.io/docs/player/components/sliders/slider-thumbnail}
 */
declare class SliderThumbnail extends Thumbnail {
    private _slider;
    protected onAttach(el: HTMLElement): void;
    protected _getTime(): number;
}

interface SliderContext {
    _disabled: ReadSignal<boolean>;
    _orientation: ReadSignal<SliderOrientation>;
    _preview: WriteSignal<HTMLElement | null>;
}
declare const sliderContext: Context<SliderContext>;

declare class LibASSTextRenderer implements TextRenderer {
    readonly loader: LibASSModuleLoader;
    config?: LibASSConfig | undefined;
    readonly priority = 1;
    private _instance;
    private _track;
    private _typeRE;
    constructor(loader: LibASSModuleLoader, config?: LibASSConfig | undefined);
    canRender(track: TextTrack, video: HTMLVideoElement | null): boolean;
    attach(video: HTMLVideoElement | null): void;
    changeTrack(track: TextTrack | null): void;
    detach(): void;
    private _freeTrack;
}
interface LibASSModuleLoader {
    (): Promise<{
        default: LibASSConstructor;
    }>;
}
interface LibASSConstructor {
    new (config?: {
        video: HTMLVideoElement;
        canvas?: HTMLCanvasElement;
        subUrl?: string;
    } & LibASSConfig): LibASSInstance;
}
interface LibASSInstance extends EventsTarget<LibASSInstanceEvents> {
    _video: HTMLVideoElement;
    _canvas: HTMLVideoElement | null;
    setTrackByUrl(url: string): void;
    setCurrentTime(time: number): void;
    freeTrack(): void;
    destroy(): void;
}
interface LibASSInstanceEvents {
    ready: LibASSReadyEvent;
    error: LibASSErrorEvent;
}
interface LibASSReadyEvent extends Event {
}
interface LibASSErrorEvent extends ErrorEvent {
}
/**
 * @see {@link https://github.com/ThaUnknown/jassub/tree/main#options}
 */
interface LibASSConfig {
    /**
     * Which image blending mode to use. WASM will perform better on lower end devices, JS will
     * perform better if the device and browser supports hardware acceleration.
     *
     * @defaultValue "js"
     */
    blendMode?: 'js' | 'wasm';
    /**
     * Whether or not to use async rendering, which offloads the CPU by creating image bitmaps on
     * the GPU.
     *
     * @defaultValue true
     */
    asyncRender?: boolean;
    /**
     * Whether or not to render things fully on the worker, greatly reduces CPU usage.
     *
     * @defaultValue true
     */
    offscreenRender?: boolean;
    /**
     * Whether or not to render subtitles as the video player renders frames, rather than predicting
     * which frame the player is on using events.
     *
     * @defaultValue true
     */
    onDemandRender?: boolean;
    /**
     * Target FPS to render subtitles at. Ignored when onDemandRender is enabled.
     *
     * @defaultValue 24
     */
    targetFps?: number;
    /**
     * Subtitle time offset in seconds.
     *
     * @defaultValue 0
     */
    timeOffset?: number;
    /**
     * Whether or not to print debug information.
     *
     * @defaultValue false
     */
    debug?: boolean;
    /**
     * Scale down (< 1.0) the subtitles canvas to improve performance at the expense of quality, or
     * scale it up (> 1.0).
     *
     * @defaultValue 1.0
     */
    prescaleFactor?: number;
    /**
     * The height in pixels beyond which the subtitles canvas won't be pre-scaled.
     *
     * @defaultValue 1080
     */
    prescaleHeightLimit?: number;
    /**
     * The maximum rendering height in pixels of the subtitles canvas. Beyond this subtitles will
     * be up-scaled by the browser.
     *
     * @defaultValue 0
     */
    maxRenderHeight?: number;
    /**
     * Attempt to discard all animated tags. Enabling this may severely mangle complex subtitles
     * and should only be considered as an last ditch effort of uncertain success for hardware
     * otherwise incapable of displaying anything. Will not reliably work with manually edited or
     * allocated events.
     *
     * @defaultValue false
     */
    dropAllAnimations?: boolean;
    /**
     * The URL of the worker.
     *
     * @defaultValue "jassub-worker.js"
     */
    workerUrl?: string;
    /**
     * The URL of the legacy worker. Only loaded if the browser doesn't support WASM.
     *
     * @defaultValue "jassub-worker-legacy.js"
     */
    legacyWorkerUrl?: string;
    /**
     * The URL of the subtitle file to play.
     *
     */
    subUrl?: string;
    /**
     * The content of the subtitle file to play.
     *
     */
    subContent?: string;
    /**
     * An array of links or `Uint8Array` to the fonts used in the subtitle. If `Uint8Array` is used
     * the array is copied, not referenced. This forces all the fonts in this array to be loaded
     * by the renderer, regardless of if they are used.
     *
     */
    fonts?: string[] | Uint8Array[];
    /**
     * Object with all available fonts. Key is font family in lower case, value is link or
     * `Uint8Array`. These fonts are selectively loaded if detected as used in the current
     * subtitle track.
     *
     * @defaultValue {'liberation sans': './default.woff2'}}
     */
    availableFonts?: Record<string, string>;
    /**
     * The font family key of the fallback font in `availableFonts` to use if the other font
     * for the style is missing special glyphs or unicode.
     *
     * @defaultValue "liberation sans"
     */
    fallbackFont?: string;
    /**
     * If the Local Font Access API is enabled `[chrome://flags/#font-access]`, the library will
     * query for permissions to use local fonts and use them if any are missing. The permission can
     * be queried beforehand using `navigator.permissions.request({ name: 'local-fonts' })`.
     *
     * @defaultValue true
     */
    useLocalFonts?: boolean;
    /**
     * libass bitmap cache memory limit in MiB (approximate).
     */
    libassMemoryLimit?: number;
    /**
     * libass glyph cache memory limit in MiB (approximate).
     */
    libassGlyphLimit?: number;
}

declare function findActiveCue(cues: readonly VTTCue[], time: number): VTTCue | null;
declare function isCueActive(cue: VTTCue, time: number): boolean;
declare function observeActiveTextTrack(tracks: TextTrackList, kind: TextTrackKind | TextTrackKind[], onChange: (track: TextTrack | null) => void): Dispose;

declare const MEDIA_KEY_SHORTCUTS: MediaKeyShortcuts;

declare class ARIAKeyShortcuts extends ViewController {
    private _shortcut;
    constructor(_shortcut: string);
    protected onAttach(el: HTMLElement): void;
}

/**
 * Formats the given `duration` into a human readable form that can be displayed to the user.
 *
 * @param duration - The length of time to parse in seconds.
 * @param shouldPadHours - Whether to pad the hours to be length of 2.
 * @param shouldPadMinutes - Whether to pad the minutes to be length of 2.
 * @param shouldAlwaysShowHours - Whether to always show the hours unit.
 * @example `01:20 -> minutes:seconds`
 * @example `3:01:20 -> hours:minutes:seconds`
 * @example If `shouldPadHours` is `true` - `03:01:20`
 * @example If `shouldAlwaysShowHours` is `true` - `0:01:20`
 */
declare function formatTime(duration: number, shouldPadHours?: boolean | null, shouldPadMinutes?: boolean | null, shouldAlwaysShowHours?: boolean): string;
/**
 * Formats the given `duration` into human spoken form.
 *
 * @param duration - The length of time to parse in seconds.
 * @example `2 hour 3 min 4 sec`
 */
declare function formatSpokenTime(duration: number): string;

/**
 * Checks if the ScreenOrientation API is available.
 *
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/Screen/orientation}
 */
declare function canOrientScreen(): boolean;
/**
 * Checks if the screen orientation can be changed.
 *
 * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/Screen/orientation}
 */
declare function canRotateScreen(): boolean;
/**
 * Checks if the native HTML5 video player can play HLS.
 */
declare function canPlayHLSNatively(video?: HTMLVideoElement): boolean;
/**
 * Checks if the native HTML5 video player can enter picture-in-picture (PIP) mode when using
 * the Chrome browser.
 *
 * @see {@link https://developers.google.com/web/updates/2018/10/watch-video-using-picture-in-picture}
 */
declare function canUsePictureInPicture(video: HTMLVideoElement): boolean;
/**
 * Checks if the native HTML5 video player can use the presentation API in Safari.
 *
 * @see {@link https://developer.apple.com/documentation/webkitjs/htmlvideoelement/1631913-webkitpresentationmode}
 */
declare function canUseVideoPresentation(video: HTMLVideoElement | null): boolean;
declare function canChangeVolume(): Promise<boolean>;

export { ARIAKeyShortcuts, AudioProvider, AudioProviderLoader, HLSProvider, HLSProviderLoader, type LibASSConfig, type LibASSConstructor, type LibASSErrorEvent, type LibASSInstance, type LibASSInstanceEvents, type LibASSModuleLoader, type LibASSReadyEvent, LibASSTextRenderer, MEDIA_KEY_SHORTCUTS, MediaContext, MediaKeyShortcuts, MediaProviderLoader, MediaSrc, MediaType, type SliderContext, SliderOrientation, SliderThumbnail, TextRenderer, TextTrack, TextTrackList, Thumbnail, VideoProvider, VideoProviderLoader, VimeoProvider, VimeoProviderLoader, YouTubeProvider, YouTubeProviderLoader, canChangeVolume, canOrientScreen, canPlayHLSNatively, canRotateScreen, canUsePictureInPicture, canUseVideoPresentation, findActiveCue, formatSpokenTime, formatTime, isAudioProvider, isCueActive, isHLSProvider, isHTMLAudioElement, isHTMLIFrameElement, isHTMLMediaElement, isHTMLVideoElement, isVideoProvider, isVimeoProvider, isYouTubeProvider, observeActiveTextTrack, sliderContext };
