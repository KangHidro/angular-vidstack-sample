const o=Symbol(0),t=Symbol(0),a={Ya:o,Za:t};function c(r){return r instanceof Error?r:Error(JSON.stringify(r))}export{a as Q,c};
