import './chunks/vidstack-9OjMWKv1.js';
import 'https://cdn.jsdelivr.net/npm/media-icons@next/dist/lazy.js';
