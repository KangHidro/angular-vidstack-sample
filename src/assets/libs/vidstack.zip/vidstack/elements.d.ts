import { M as MaverickElementConstructor, A as Attributes, d as Component, T as TemplateResult, e as RootPart } from './dist/types/vidstack-YccYOULG.js';
export { g as defineCustomElement } from './dist/types/vidstack-YccYOULG.js';
import { fw as Captions, fn as Gesture, dx as MediaProvider, E as MediaPlayerProps, du as MediaPlayer, fz as Poster, c as MediaContext, T as Thumbnail, fA as Time, dy as Controls, dC as ControlsGroup, b$ as PlayerQueryList, dl as DefaultAudioLayout, dm as DefaultVideoLayout, dO as PlayButton, dU as MuteButton, dQ as CaptionButton, dS as FullscreenButton, dW as PIPButton, dY as SeekButton, dM as ToggleButton, dL as ToggleButtonProps, d_ as LiveButton, dD as Tooltip, dF as TooltipTrigger, dG as TooltipContent, f4 as AudioRadioGroup, f9 as CaptionsRadioGroup, ey as Menu, eD as MenuButton, eJ as MenuPortalProps, eI as MenuPortal, eH as MenuItem, eM as MenuItems, e$ as ChaptersRadioGroup, fe as SpeedRadioGroup, fi as QualityRadioGroup, eV as Radio, eR as RadioGroup, ea as Slider, em as SliderValueProps, el as SliderValue, ef as SliderVideo, es as TimeSlider, en as SliderPreview, er as VolumeSlider, ev as SliderChapters } from './dist/types/vidstack-rg4gqF4B.js';
import 'media-captions';
import 'hls.js';

declare const MediaCaptionsElement_base: MaverickElementConstructor<HTMLElement, Captions>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/captions}
 * @example
 * ```html
 * <media-captions></media-captions>
 * ```
 */
declare class MediaCaptionsElement extends MediaCaptionsElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-captions': MediaCaptionsElement;
    }
}

declare const MediaGestureElement_base: MaverickElementConstructor<HTMLElement, Gesture>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/gesture}
 * @example
 * ```html
 * <media-player>
 *   <media-provider>
 *     <media-gesture event="pointerup" action="toggle:paused"></media-gesture>
 *   </media-provider>
 * </media-player>
 * ```
 */
declare class MediaGestureElement extends MediaGestureElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-gesture': MediaGestureElement;
    }
}

declare const MediaProviderElement_base: MaverickElementConstructor<HTMLElement, MediaProvider>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/core/provider}
 * @example
 * ```html
 * <media-player>
 *   <media-provider></media-provider>
 *   <!-- ... -->
 * </media-player>
 * ```
 */
declare class MediaProviderElement extends MediaProviderElement_base {
    static tagName: string;
    private _media;
    private _target;
    private _blocker;
    protected onSetup(): void;
    protected onDestroy(): void;
    protected onConnect(): void;
    private _createAudio;
    private _createVideo;
    private _createIFrame;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-provider': MediaProviderElement;
    }
}

declare const MediaPlayerElement_base: MaverickElementConstructor<HTMLElement, MediaPlayer>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/core/player}
 * @example
 * ```html
 * <media-player src="...">
 *   <media-provider></media-provider>
 *   <!-- Other components that use/manage media state here. -->
 * </media-player>
 * ```
 */
declare class MediaPlayerElement extends MediaPlayerElement_base {
    static tagName: string;
    static attrs: Attributes<MediaPlayerProps>;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-player': MediaPlayerElement;
    }
}

declare const MediaPosterElement_base: MaverickElementConstructor<HTMLElement, Poster>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/poster}
 * @example
 * ```html
 * <media-player>
 *   <media-poster src="..." alt="Large alien ship hovering over New York."></media-poster>
 * </media-player>
 * ```
 */
declare class MediaPosterElement extends MediaPosterElement_base {
    static tagName: string;
    private _media;
    private _img;
    protected onSetup(): void;
    protected onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-poster': MediaPosterElement;
    }
}

declare const MediaThumbnailElement_base: MaverickElementConstructor<HTMLElement, Thumbnail>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/thumbnail}
 * @example
 * ```html
 * <media-player>
 *   <!-- ... -->
 *   <media-thumbnail
 *     src="https://media-files.vidstack.io/thumbnails.vtt"
 *     time="10"
 *   ></media-thumbnail>
 * </media-player>
 * ```
 */
declare class MediaThumbnailElement extends MediaThumbnailElement_base {
    static tagName: string;
    protected _media: MediaContext;
    protected _img: HTMLImageElement;
    protected onSetup(): void;
    protected onConnect(): void;
    private _createImg;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-thumbnail': MediaThumbnailElement;
    }
}

declare const MediaTimeElement_base: MaverickElementConstructor<HTMLElement, Time>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/time}
 * @example
 * ```html
 * <media-time type="current"></media-time>
 * ```
 * @example
 * ```html
 * <!-- Remaining time. -->
 * <media-time type="current" remainder></media-time>
 * ```
 */
declare class MediaTimeElement extends MediaTimeElement_base {
    static tagName: string;
    protected onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-time': MediaTimeElement;
    }
}

declare const MediaControlsElement_base: MaverickElementConstructor<HTMLElement, Controls>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/controls}
 * @example
 * ```html
 * <media-player>
 *   <!-- ... -->
 *   <media-controls>
 *     <media-controls-group></media-controls-group>
 *     <media-controls-group></media-controls-group>
 *   </media-controls>
 * </media-player>
 * ```
 */
declare class MediaControlsElement extends MediaControlsElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-controls': MediaControlsElement;
    }
}

declare const MediaControlsGroupElement_base: MaverickElementConstructor<HTMLElement, ControlsGroup>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/controls}
 * @example
 * ```html
 * <media-player>
 *   <!-- ... -->
 *   <media-controls>
 *     <media-controls-group></media-controls-group>
 *     <media-controls-group></media-controls-group>
 *   </media-controls>
 * </media-player>
 * ```
 */
declare class MediaControlsGroupElement extends MediaControlsGroupElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-controls-group': MediaControlsGroupElement;
    }
}

declare class ChapterTitle extends Component {
}
declare const MediaChapterTitleElement_base: MaverickElementConstructor<HTMLElement, ChapterTitle>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/chapter-title}
 * @example
 * ```html
 * <media-chapter-title></media-chapter-title>
 * ```
 */
declare class MediaChapterTitleElement extends MediaChapterTitleElement_base {
    static tagName: string;
    private _media;
    private _title;
    private _chapterTitle;
    protected onSetup(): void;
    protected onConnect(): void;
    protected _getTitle(): string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-chapter-title': MediaChapterTitleElement;
    }
}

declare class LitElement extends HTMLElement {
    rootPart: RootPart | null;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
interface LitRenderer {
    render(): TemplateResult;
}

interface SpinnerProps {
    /**
     * The horizontal (width) and vertical (height) length of the spinner.
     */
    size: number;
    /**
     * The width of the spinner track and track fill.
     */
    trackWidth: number;
    /**
     * The percentage of the spinner track that should be filled.
     */
    fillPercent: number;
}
declare class Spinner extends Component<SpinnerProps> {
    static props: SpinnerProps;
    protected onConnect(el: HTMLElement): void;
    private _update;
}
declare const MediaSpinnerElement_base: MaverickElementConstructor<LitElement, Spinner>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/display/buffering-indicator}
 * @example
 * ```html
 * <!-- default values below -->
 * <media-spinner size="84" track-width="8" fill-percent="50"></media-spinner>
 * ```
 * @example
 * ```css
 * media-spinner [data-part="track"] {
 *   color: rgb(255 255 255 / 0.5);
 * }
 *
 * media-spinner [data-part="track-fill"] {
 *   color: white;
 * }
 * ```
 */
declare class MediaSpinnerElement extends MediaSpinnerElement_base {
    static tagName: string;
    render(): TemplateResult<1>;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-spinner': MediaSpinnerElement;
    }
}

declare class MediaLayout extends Component<{
    when: string;
}> {
    static props: {
        when: string;
    };
}
declare const MediaLayoutElement_base: MaverickElementConstructor<HTMLElement, MediaLayout>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/layouts#custom}
 * @example
 * ```html
 * <media-layout when="(view-type: video)">
 *   <template>
 *     <!-- ... -->
 *   </template>
 * </media-layout>
 * ```
 */
declare class MediaLayoutElement extends MediaLayoutElement_base {
    static tagName: string;
    query: PlayerQueryList;
    protected onSetup(): void;
    protected onConnect(): void;
    private _watchQuery;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-layout': MediaLayoutElement;
    }
}

declare const MediaAudioLayoutElement_base: MaverickElementConstructor<LitElement, DefaultAudioLayout>;
/**
 * @docs {@link https://www.vidstack.io/docs/player/components/layouts/default-layout}
 * @example
 * ```html
 * <media-player>
 *   <media-provider></media-provider>
 *   <media-audio-layout></media-audio-layout>
 * </media-player>
 * ```
 */
declare class MediaAudioLayoutElement extends MediaAudioLayoutElement_base implements LitRenderer {
    static tagName: string;
    private _media;
    protected onSetup(): void;
    protected onConnect(): void;
    private _render;
    render(): TemplateResult<1>;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-audio-layout': MediaAudioLayoutElement;
    }
}

declare const MediaVideoLayoutElement_base: MaverickElementConstructor<LitElement, DefaultVideoLayout>;
/**
 * @docs {@link https://www.vidstack.io/docs/player/components/layouts/default-layout}
 * @example
 * ```html
 * <media-player>
 *   <media-provider></media-provider>
 *   <media-video-layout></media-video-layout>
 * </media-player>
 * ```
 */
declare class MediaVideoLayoutElement extends MediaVideoLayoutElement_base implements LitRenderer {
    static tagName: string;
    private _media;
    protected onSetup(): void;
    protected onConnect(): void;
    private _render;
    render(): TemplateResult<1>;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-video-layout': MediaVideoLayoutElement;
    }
}

declare const MediaPlayButtonElement_base: MaverickElementConstructor<HTMLElement, PlayButton>;
/**
 * @example
 * ```html
 * <media-play-button>
 *   <media-icon type="play"></media-icon>
 *   <media-icon type="pause"></media-icon>
 *   <media-icon type="replay"></media-icon>
 * </media-play-button>
 * ```
 */
declare class MediaPlayButtonElement extends MediaPlayButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-play-button': MediaPlayButtonElement;
    }
}

declare const MediaMuteButtonElement_base: MaverickElementConstructor<HTMLElement, MuteButton>;
/**
 * @example
 * ```html
 * <media-mute-button>
 *   <media-icon type="mute"></media-icon>
 *   <media-icon type="volume-low"></media-icon>
 *   <media-icon type="volume-high"></media-icon>
 * </media-mute-button>
 * ```
 */
declare class MediaMuteButtonElement extends MediaMuteButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-mute-button': MediaMuteButtonElement;
    }
}

declare const MediaCaptionButtonElement_base: MaverickElementConstructor<HTMLElement, CaptionButton>;
/**
 * @example
 * ```html
 * <media-caption-button>
 *   <media-icon type="closed-captions-on"></media-icon>
 *   <media-icon type="closed-captions"></media-icon>
 * </media-caption-button>
 * ```
 */
declare class MediaCaptionButtonElement extends MediaCaptionButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-caption-button': MediaCaptionButtonElement;
    }
}

declare const MediaFullscreenButtonElement_base: MaverickElementConstructor<HTMLElement, FullscreenButton>;
/**
 * @example
 * ```html
 * <media-fullscreen-button>
 *   <media-icon type="fullscreen"></media-icon>
 *   <media-icon type="fullscreen-exit"></media-icon>
 * </media-fullscreen-button>
 * ```
 */
declare class MediaFullscreenButtonElement extends MediaFullscreenButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-fullscreen-button': MediaFullscreenButtonElement;
    }
}

declare const MediaPIPButtonElement_base: MaverickElementConstructor<HTMLElement, PIPButton>;
/**
 * @example
 * ```html
 * <media-pip-button>
 *   <media-icon type="picture-in-picture"></media-icon>
 *   <media-icon type="picture-in-picture-exit"></media-icon>
 * </media-pip-button>
 * ```
 */
declare class MediaPIPButtonElement extends MediaPIPButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-pip-button': MediaPIPButtonElement;
    }
}

declare const MediaSeekButtonElement_base: MaverickElementConstructor<HTMLElement, SeekButton>;
/**
 * @example
 * ```html
 * <!-- Forward +30s on each press. -->
 * <media-seek-button seconds="+30">
 *   <media-icon type="seek-forward"></media-icon>
 * </media-seek-button>
 * <!-- Backward -30s on each press. -->
 * <media-seek-button seconds="-30">
 *   <media-icon type="seek-backward"></media-icon>
 * </media-seek-button>
 * ```
 */
declare class MediaSeekButtonElement extends MediaSeekButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-seek-button': MediaSeekButtonElement;
    }
}

declare const MediaToggleButtonElement_base: MaverickElementConstructor<HTMLElement, ToggleButton<ToggleButtonProps>>;
/**
 * @example
 * ```html
 * <media-toggle-button aria-label="...">
 *   <!-- ... -->
 * </media-toggle-button>
 * ```
 */
declare class MediaToggleButtonElement extends MediaToggleButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-toggle-button': MediaToggleButtonElement;
    }
}

declare const MediaLiveButtonElement_base: MaverickElementConstructor<HTMLElement, LiveButton>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/buttons/live-button}
 * @example
 * ```html
 * <media-live-button>
 *   <!-- ... -->
 * </media-live-button>
 * ```
 */
declare class MediaLiveButtonElement extends MediaLiveButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-live-button': MediaLiveButtonElement;
    }
}

declare const MediaTooltipElement_base: MaverickElementConstructor<HTMLElement, Tooltip>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/tooltip}
 * @example
 * ```html
 * <media-tooltip>
 *   <media-tooltip-trigger>
 *     <media-play-button></media-play-button>
 *   </media-tooltip-trigger>
 *   <media-tooltip-content placement="top start">
 *      <span class="play-tooltip-text">Play</span>
 *      <span class="pause-tooltip-text">Pause</span>
 *   </media-tooltip-content>
 * </media-tooltip>
 * ```
 */
declare class MediaTooltipElement extends MediaTooltipElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-tooltip': MediaTooltipElement;
    }
}

declare const MediaTooltipTriggerElement_base: MaverickElementConstructor<HTMLElement, TooltipTrigger>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/tooltip}
 * @example
 * ```html
 * <media-tooltip>
 *   <media-tooltip-trigger>
 *     <media-play-button></media-play-button>
 *   </media-tooltip-trigger>
 *   <media-tooltip-content placement="top start">
 *      <span class="play-tooltip-text">Play</span>
 *      <span class="pause-tooltip-text">Pause</span>
 *   </media-tooltip-content>
 * </media-tooltip>
 * ```
 */
declare class MediaTooltipTriggerElement extends MediaTooltipTriggerElement_base {
    static tagName: string;
    onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-tooltip-trigger': MediaTooltipTriggerElement;
    }
}

declare const MediaTooltipContentElement_base: MaverickElementConstructor<HTMLElement, TooltipContent>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/tooltip}
 * @example
 * ```html
 * <media-tooltip>
 *   <media-tooltip-trigger>
 *     <media-play-button></media-play-button>
 *   </media-tooltip-trigger>
 *   <media-tooltip-content placement="top">
 *      <span class="play-tooltip-text">Play</span>
 *      <span class="pause-tooltip-text">Pause</span>
 *   </media-tooltip-content>
 * </media-tooltip>
 * ```
 */
declare class MediaTooltipContentElement extends MediaTooltipContentElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-tooltip-content': MediaTooltipContentElement;
    }
}

declare const MediaAudioRadioGroupElement_base: MaverickElementConstructor<HTMLElement, AudioRadioGroup>;
/**
 * @part label - Contains the audio track option label.
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/audio-menu}
 * @example
 * ```html
 * <media-menu>
 *   <!-- ... -->
 *   <media-menu-items>
 *     <media-audio-radio-group>
 *       <template>
 *         <media-radio>
 *           <span data-part="label"></span>
 *         </media-radio>
 *       </template>
 *     </media-audio-radio-group>
 *   </media-menu-items>
 * </media-menu>
 * ```
 */
declare class MediaAudioRadioGroupElement extends MediaAudioRadioGroupElement_base {
    static tagName: string;
    protected onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-audio-radio-group': MediaAudioRadioGroupElement;
    }
}

declare const MediaCaptionsRadioGroupElement_base: MaverickElementConstructor<HTMLElement, CaptionsRadioGroup>;
/**
 * @part label - Contains the caption/subtitle option label.
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/captions-menu-items}
 * @example
 * ```html
 * <media-menu>
 *   <!-- ... -->
 *   <media-menu-items>
 *     <media-captions-radio-group>
 *       <template>
 *         <media-radio>
 *           <span data-part="label"></span>
 *         </media-radio>
 *       </template>
 *     </media-captions-radio-group>
 *   </media-menu-items>
 * </media-menu>
 * ```
 */
declare class MediaCaptionsRadioGroupElement extends MediaCaptionsRadioGroupElement_base {
    static tagName: string;
    protected onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-captions-radio-group': MediaCaptionsRadioGroupElement;
    }
}

declare const MediaMenuElement_base: MaverickElementConstructor<HTMLElement, Menu>;
/**
 * @part close-target - Closes menu when pressed.
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/menu}
 * @example
 * ```html
 * <media-menu>
 *   <media-menu-button aria-label="Settings">
 *     <media-icon type="settings"></media-icon>
 *   </media-menu-button>
 *   <media-menu-items>
 *     <!-- ... -->
 *   </media-menu-items>
 * </media-menu>
 * ```
 */
declare class MediaMenuElement extends MediaMenuElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-menu': MediaMenuElement;
    }
}

declare const MediaMenuButtonElement_base: MaverickElementConstructor<HTMLElement, MenuButton>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/menu}
 * @example
 * ```html
 * <media-menu>
 *   <media-menu-button aria-label="Settings">
 *     <media-icon type="settings"></media-icon>
 *   </media-menu-button>
 *   <media-menu-items>
 *     <!-- ... -->
 *   </media-menu-items>
 * </media-menu>
 * ```
 */
declare class MediaMenuButtonElement extends MediaMenuButtonElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-menu-button': MediaMenuButtonElement;
    }
}

declare const MediaMenuPortalElement_base: MaverickElementConstructor<HTMLElement, MenuPortal>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/menu#portal}
 * @example
 * ```html
 * <media-menu>
 *   <!-- ... -->
 *   <media-menu-portal>
 *     <media-menu-items></media-menu-items>
 *   </media-menu-portal>
 * </media-menu>
 * ```
 */
declare class MediaMenuPortalElement extends MediaMenuPortalElement_base {
    static tagName: string;
    static attrs: Attributes<MenuPortalProps>;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-menu-portal': MediaMenuPortalElement;
    }
}

declare const MediaMenuItemElement_base: MaverickElementConstructor<HTMLElement, MenuItem>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/menu}
 * @example
 * ```html
 * <media-menu>
 *   <media-menu-items>
 *      <media-menu-item></media-menu-item>
 *   </media-menu-items>
 * </media-menu>
 * ```
 */
declare class MediaMenuItemElement extends MediaMenuItemElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-menu-item': MediaMenuItemElement;
    }
}

declare const MediaMenuItemsElement_base: MaverickElementConstructor<HTMLElement, MenuItems>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/menu}
 * @example
 * ```html
 * <media-menu>
 *   <media-menu-button aria-label="Settings">
 *     <media-icon type="settings"></media-icon>
 *   </media-menu-button>
 *   <media-menu-items>
 *     <!-- ... -->
 *   </media-menu-items>
 * </media-menu>
 * ```
 */
declare class MediaMenuItemsElement extends MediaMenuItemsElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-menu-items': MediaMenuItemsElement;
    }
}

declare const MediaChaptersRadioGroupElement_base: MaverickElementConstructor<HTMLElement, ChaptersRadioGroup>;
/**
 * @part label - Contains the chapter option title.
 * @part start-time - Contains the chapter option start time.
 * @part duration - Contains the chapter option duration.
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/chapters-menu}
 * @example
 * ```html
 * <media-menu>
 *   <media-menu-button aria-label="Chapters">
 *     <media-icon type="chapters"></media-icon>
 *   </media-menu-button>
 *   <media-chapters-radio-group thumbnails="...">
 *     <template>
 *       <media-radio>
 *         <media-thumbnail></media-thumbnail>
 *         <span data-part="label"></span>
 *         <span data-part="start-time"></span>
 *         <span data-part="duration"></span>
 *       </media-radio>
 *     </template>
 *    </media-chapters-radio-group>
 * </media-menu>
 * ```
 */
declare class MediaChaptersRadioGroupElement extends MediaChaptersRadioGroupElement_base {
    static tagName: string;
    protected onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-chapters-radio-group': MediaChaptersRadioGroupElement;
    }
}

declare const MediaSpeedRadioGroupElement_base: MaverickElementConstructor<HTMLElement, SpeedRadioGroup>;
/**
 * @part label - Contains the speed option label.
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/playback-rate-menu}
 * @example
 * ```html
 * <media-menu>
 *   <!-- ... -->
 *   <media-menu-items>
 *     <media-speed-radio-group>
 *       <template>
 *         <media-radio>
 *           <span data-part="label"></span>
 *         </media-radio>
 *       </template>
 *     </media-speed-radio-group>
 *   </media-menu-items>
 * </media-menu>
 * ```
 */
declare class MediaSpeedRadioGroupElement extends MediaSpeedRadioGroupElement_base {
    static tagName: string;
    protected onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-speed-radio-group': MediaSpeedRadioGroupElement;
    }
}

declare const MediaQualityRadioGroupElement_base: MaverickElementConstructor<HTMLElement, QualityRadioGroup>;
/**
 * @part label - Contains the quality option label.
 * @part bitrate - Contains the quality option bitrate.
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/quality-menu}
 * @example
 * ```html
 * <media-menu>
 *   <!-- ... -->
 *   <media-menu-items>
 *     <media-quality-radio-group>
 *       <template>
 *         <media-radio>
 *           <span data-part="label"></span>
 *           <span data-part="bitrate"></span>
 *         </media-radio>
 *       </template>
 *     </media-quality-radio-group>
 *   </media-menu-items>
 * </media-menu>
 * ```
 */
declare class MediaQualityRadioGroupElement extends MediaQualityRadioGroupElement_base {
    static tagName: string;
    protected onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-quality-radio-group': MediaQualityRadioGroupElement;
    }
}

declare const MediaRadioElement_base: MaverickElementConstructor<HTMLElement, Radio>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/radio}
 * @example
 * ```html
 * <media-radio-group value="720">
 *   <media-radio value="1080">1080p</media-radio>
 *   <media-radio value="720">720p</media-radio>
 *   <!-- ... -->
 * </media-radio-group>
 * ```
 */
declare class MediaRadioElement extends MediaRadioElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-radio': MediaRadioElement;
    }
}

declare const MediaRadioGroupElement_base: MaverickElementConstructor<HTMLElement, RadioGroup>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/menu/radio-group}
 * @example
 * ```html
 * <media-radio-group value="720">
 *   <media-radio value="1080">1080p</media-radio>
 *   <media-radio value="720">720p</media-radio>
 *   <!-- ... -->
 * </media-radio-group>
 * ```
 */
declare class MediaRadioGroupElement extends MediaRadioGroupElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-radio-group': MediaRadioGroupElement;
    }
}

declare const MediaSliderElement_base: MaverickElementConstructor<HTMLElement, Slider>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/sliders/slider}
 * @example
 * ```html
 * <media-slider min="0" max="100" value="50" aria-label="...">
 *   <div class="track"></div>
 *   <div class="track-fill"></div>
 *   <div class="track-progress"></div>
 *   <div class="thumb"></div>
 * </media-slider>
 * ```
 */
declare class MediaSliderElement extends MediaSliderElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-slider': MediaSliderElement;
    }
}

/**
 * @example
 * ```html
 * <media-player >
 *   <media-time-slider>
 *     <media-slider-preview>
 *       <media-slider-thumbnail
 *         src="https://media-files.vidstack.io/thumbnails.vtt"
 *       ></media-slider-thumbnail>
 *     </media-slider-preview>
 *   </media-time-slider>
 * </media-player>
 * ```
 */
declare class MediaSliderThumbnailElement extends MediaThumbnailElement {
    static tagName: string;
    private _slider;
    protected onSetup(): void;
    protected onConnect(): void;
    private _watchTime;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-slider-thumbnail': MediaSliderThumbnailElement;
    }
}

declare const MediaSliderValueElement_base: MaverickElementConstructor<HTMLElement, SliderValue>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/sliders/slider-value}
 * @example
 * ```html
 * <media-time-slider>
 *   <media-slider-preview>
 *     <media-slider-value></media-slider-value>
 *   </media-slider-preview>
 * </media-time-slider>
 * ```
 * @example
 * ```html
 * <media-slider-value type="current"></media-slider-value>
 * ```
 * @example
 * ```html
 * <media-slider-value show-hours pad-hours></media-slider-value>
 * ```
 * @example
 * ```html
 * <media-slider-value decimal-places="2"></media-slider-value>
 * ```
 */
declare class MediaSliderValueElement extends MediaSliderValueElement_base {
    static tagName: string;
    static attrs: Attributes<SliderValueProps>;
    protected onConnect(): void;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-slider-value': MediaSliderValueElement;
    }
}

declare const MediaSliderVideoElement_base: MaverickElementConstructor<HTMLElement, SliderVideo>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/sliders/slider-video}
 * @example
 * ```html
 * <media-time-slider>
 *   <media-slider-preview>
 *     <media-slider-video src="/low-res-video.mp4"></media-slider-video>
 *   </media-slider-preview>
 * </media-time-slider>
 * ```
 */
declare class MediaSliderVideoElement extends MediaSliderVideoElement_base {
    static tagName: string;
    private _media;
    private _video;
    protected onSetup(): void;
    protected onConnect(): void;
    private _createVideo;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-slider-video': MediaSliderVideoElement;
    }
}

declare const MediaTimeSliderElement_base: MaverickElementConstructor<HTMLElement, TimeSlider>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/sliders/time-slider}
 * @example
 * ```html
 * <media-time-slider>
 *   <div class="track"></div>
 *   <div class="track-fill"></div>
 *   <div class="track-progress"></div>
 *   <div class="thumb"></div>
 * </media-time-slider>
 * ```
 * @example
 * ```html
 * <media-time-slider>
 *   <!-- ... -->
 *   <media-slider-preview>
 *     <media-slider-value></media-slider-value>
 *   <media-slider-preview>
 * </media-time-slider>
 * ```
 */
declare class MediaTimeSliderElement extends MediaTimeSliderElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-time-slider': MediaTimeSliderElement;
    }
}

declare const MediaSliderPreviewElement_base: MaverickElementConstructor<HTMLElement, SliderPreview>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/sliders/slider#preview}
 */
declare class MediaSliderPreviewElement extends MediaSliderPreviewElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-slider-preview': MediaSliderPreviewElement;
    }
}

declare const MediaVolumeSliderElement_base: MaverickElementConstructor<HTMLElement, VolumeSlider>;
/**
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/sliders/volume-slider}
 * @example
 * ```html
 * <media-volume-slider>
 *   <div class="track"></div>
 *   <div class="track-fill"></div>
 *   <div class="track-progress"></div>
 *   <div class="thumb"></div>
 * </media-volume-slider>
 * ```
 * @example
 * ```html
 * <media-volume-slider>
 *   <!-- ... -->
 *   <media-slider-preview>
 *     <media-slider-value></media-slider-value>
 *   </media-slider-preview>
 * </media-volume-slider>
 * ```
 */
declare class MediaVolumeSliderElement extends MediaVolumeSliderElement_base {
    static tagName: string;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-volume-slider': MediaVolumeSliderElement;
    }
}

declare const MediaSliderChaptersElement_base: MaverickElementConstructor<HTMLElement, SliderChapters>;
/**
 * @part chapter-title - Contains the current chapter title.
 * @docs {@link https://www.vidstack.io/docs/wc/player/components/sliders/slider-chapters}
 * @example
 * ```html
 * <media-time-slider>
 *   <media-slider-chapters>
 *     <template>
 *       <div class="slider-chapter">
 *         <div class="slider-track"></div>
 *         <div class="slider-track-fill"></div>
 *         <div class="slider-track-progress"></div>
 *       </div>
 *     </template>
 *   </media-slider-chapters>
 * </media-time-slider>
 * ```
 * ```
 */
declare class MediaSliderChaptersElement extends MediaSliderChaptersElement_base {
    static tagName: string;
    protected _template: HTMLTemplateElement | null;
    protected onConnect(): void;
    private _renderTemplate;
}
declare global {
    interface HTMLElementTagNameMap {
        'media-slider-chapters': MediaSliderChaptersElement;
    }
}

export { MediaAudioLayoutElement, MediaAudioRadioGroupElement, MediaCaptionButtonElement, MediaCaptionsElement, MediaCaptionsRadioGroupElement, MediaChapterTitleElement, MediaChaptersRadioGroupElement, MediaControlsElement, MediaControlsGroupElement, MediaFullscreenButtonElement, MediaGestureElement, MediaLayoutElement, MediaLiveButtonElement, MediaMenuButtonElement, MediaMenuElement, MediaMenuItemElement, MediaMenuItemsElement, MediaMenuPortalElement, MediaMuteButtonElement, MediaPIPButtonElement, MediaPlayButtonElement, MediaPlayerElement, MediaPosterElement, MediaProviderElement, MediaQualityRadioGroupElement, MediaRadioElement, MediaRadioGroupElement, MediaSeekButtonElement, MediaSliderChaptersElement, MediaSliderElement, MediaSliderPreviewElement, MediaSliderThumbnailElement, MediaSliderValueElement, MediaSliderVideoElement, MediaSpeedRadioGroupElement, MediaSpinnerElement, MediaThumbnailElement, MediaTimeElement, MediaTimeSliderElement, MediaToggleButtonElement, MediaTooltipContentElement, MediaTooltipElement, MediaTooltipTriggerElement, MediaVideoLayoutElement, MediaVolumeSliderElement };
